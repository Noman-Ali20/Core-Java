package demo;

public class Client {

	public static void main(String[] args) {
		SBI sbi = new SBI();
		sbi.rateOfInterest();
		
		CBI cbi = new CBI();
		cbi.rateOfInterest();
		
	}

}
