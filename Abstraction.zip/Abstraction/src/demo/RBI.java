package demo;

public abstract class RBI {
	 abstract void rateOfInterest();
}
