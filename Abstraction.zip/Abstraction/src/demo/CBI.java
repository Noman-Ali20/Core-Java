package demo;

public class CBI extends RBI{

	void rateOfInterest() {
		System.out.println("9%");
		
	}

}
