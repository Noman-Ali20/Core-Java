package demo;

class SBI extends RBI{

	 void rateOfInterest() {
		System.out.println("7%");
	}
	
	

}
